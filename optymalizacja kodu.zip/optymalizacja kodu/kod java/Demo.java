import java.io.IOException;
import java.io.InputStream;

class Demo {
	public static void main(String argc[]) throws IOException {
		String plikRO = "testowytxt.txt";
		String plikRW = "nowyPlik.txt";
		TheFiles f = new TheFiles();
		f.saveFile(plikRW,"Ahjsavgjfsaj");
		String c = f.readFile(plikRW);
		System.out.println(c);
		ClassLoader classLoader = Demo.class.getClassLoader();
		InputStream input = classLoader.getResourceAsStream(plikRO);
		String c2 = f.readFileStr(input);
		System.out.println(c2);
		Archives a = new Archives();
		String archName = "noweArchiwum";
		a.pack(archName,plikRO);
		a.pack(archName+"Multi",plikRO+","+plikRW);
		a.unpack(archName,"./unpack",plikRO);
	}
}
