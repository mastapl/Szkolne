<?php
class FileSystem
{
	public $dmsg = "";
	
	function construct($id){
		echo "ID instancji: ".$id;
	}
	public function get($dir, $file){
		$out = false;
		if( is_dir($dir) )
		{
			// $dir'/'.$file -> $dir.'/'.$file
			$this->dmsg = 'Direction exists: '.$dir;
			if(file_exists($dir.'/'.$file)){
				$this->dmsg = $dir.'/'.$file;
				$out = true;
			} else
				$this->dmsg = $dir.'/'.$file;
		} else
			$this->dmsg = $dir;
	return $out;
	}
}
	$filesys = new FileSystem();

	if($filesys->get('./media', 'dokument.html') || $filesys->get('./media/assets', 'dokument.html')) {
		echo 'File been found';
	}
	else {
		echo 'File not been found';
	}
?>
