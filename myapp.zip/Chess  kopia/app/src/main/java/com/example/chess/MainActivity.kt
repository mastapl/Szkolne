package com.example.chess
import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.ContextMenu
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.GridLayout
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var chessboardLayout: GridLayout

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        chessboardLayout = findViewById(R.id.chessboardLayout)
        createChessboard()
        registerForContextMenu(chessboardLayout)
    }

    private fun createChessboard() {
        val numRows = 8
        val numCols = 8

        for (row in 0 until numRows) {
            for (col in 0 until numCols) {
                val square = View(this)
                square.layoutParams = GridLayout.LayoutParams().apply {
                    width = 0
                    height = 0
                    columnSpec = GridLayout.spec(col, 1f)
                    rowSpec = GridLayout.spec(row, 1f)
                }
                if ((row + col) % 2 == 0) {
                    square.setBackgroundColor(Color.WHITE)
                } else {
                    square.setBackgroundColor(Color.BLACK)
                }
                chessboardLayout.addView(square)
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.context_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_item_white -> {
                changeChessboardColor(Color.WHITE)
                return true
            }
            R.id.menu_item_black -> {
                changeChessboardColor(Color.BLACK)
                return true
            }
            R.id.menu_item_yellow -> {
                changeChessboardColor(Color.YELLOW)
                return true
            }
            R.id.menu_item_blue -> {
                changeChessboardColor(Color.BLUE)
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    private fun changeChessboardColor(color: Int) {
        for (i in 0 until chessboardLayout.childCount) {
            val square = chessboardLayout.getChildAt(i)
            square.setBackgroundColor(color)
        }
    }

    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menuInflater.inflate(R.menu.context_menu, menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_item_white-> {
                changeChessboardColor(Color.WHITE)
                return true
            }
            R.id.menu_item_black -> {
                changeChessboardColor(Color.BLACK)
                return true
            }
            R.id.menu_item_yellow-> {
                changeChessboardColor(Color.YELLOW)
                return true
            }
            R.id.menu_item_blue -> {
                changeChessboardColor(Color.BLUE)
                return true
            }
            else -> return super.onContextItemSelected(item)
        }
    }
}
